package com.example.projectweb;

import android.content.DialogInterface;

public interface OnDialogCloseListner {
    void onDialogClose(DialogInterface dialogInterface);
}
